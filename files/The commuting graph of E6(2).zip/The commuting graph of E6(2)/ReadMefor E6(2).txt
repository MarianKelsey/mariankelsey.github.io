The Folders contains  the orbits representative  of the commuting involution graphs :

1-E6(2)group= 27-dimension matrix representation   E6(2).

2-E6A= Orbits representative of C(E6(2),2A), with subfolders described as follows:
a-fixed element in the class 2A namely  by E6AA.
b-CG(t)-orbits  representatives  in the set Xc   described  as follows:
E6A(name of the class) for example E6A2A means the orbit in the set Xc where c=2A. 


3-E6B= Orbits representative of C(E6(2),2B), with subfolders described as follows:
a-fixed element in the class 2B namely  by E6BB.
b-CG(t)-orbits  representatives  in the set Xc   described  as follows:
E6B(name of the class) for example E6A2B means the orbit in the set Xc where c=2B. 



4-E6C= Orbits representative of C(E6(2),2C), with subfolders described as follows:
a-fixed element in the class 2C namely  by E6CC.
b-CG(t)-orbits  representatives  in the set Xc   described  as follows:
E6C(name of the class) for example E6A2C means the orbit in the set Xc where c=2C. 



Note: To access to any files 
1-Open the file.
2- Copy the content of the file.
3- Paste  the content of the file inside magma.  


