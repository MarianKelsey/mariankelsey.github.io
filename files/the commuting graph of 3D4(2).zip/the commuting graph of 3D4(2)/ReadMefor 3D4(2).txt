The Folders contains  the orbits representative  of the commuting involution graphs :

1-3D4(2)group= TD4(2) represented as permutations on 819 points.

2-3D4(2),2A= Orbits representative of C(3D4(2),2A), with subfolders described as follows:
a-fixed element in the class 2A namely  by DA.
b-CG(t)-orbits  representatives  in the set Xc   described  as follows:
DA(name of the class) for example DA2A means the orbit in the set Xc where c=2A. 


3-3D4(2),2B= Orbits representative of C(3D4(2),2B), with subfolders described as follows:
a-fixed element in the class 2B namely  by DB.
b-CG(t)-orbits  representatives  in the set Xc   described  as follows:
DB(name of the class) for example DB3A means the orbit in the set Xc where c=3A. 


Note: To access to any files 
1-Open the file.
2- Copy the content of the file.
3- Paste  the content of the file inside magma.  


