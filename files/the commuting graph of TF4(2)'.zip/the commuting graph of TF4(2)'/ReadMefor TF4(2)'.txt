The Folders contains  the orbits representative  of the commuting involution graphs :

1-TF4(2)'= TF4(2)' represented as permutations on 1600 points.

2-TwisF4, 2A= Orbits representative of C(2F4(2)',2A), with subfolders described as follows:
a-fixed element in the class 2A namely  by TSA.
b-CG(t)-orbits  representatives  in the set Xc   described  as follows:
TSA(name of the class) for example TSA2A means the orbit in the set Xc where c=2A. 


3-TwisF4, 2B= Orbits representative of C(2F4(2)',2B), with subfolders described as follows:
a-fixed element in the class 2B namely  by TSB.
b-CG(t)-orbits  representatives  in the set Xc   described  as follows:
TSB(name of the class) for example TSB2A means the orbit in the set Xc where c=2A. 


Note: To access to any files 
1-Open the file.
2- Copy the content of the file.
3- Paste  the content of the file inside magma.  


